-- Sales,Profit by Category --
select Category,sum(Sales) as Sales,sum(Profit) as Profit
from orders
group by Category
order by Sales desc;
-- Output --
"category"	"sales"	"profit"
"Technology"	836154.033	145454.9481
"Furniture"	741999.7953	18451.2728
"Office Supplies"	719047.032	122490.8008

-- Total Sales & Profit --
SELECT SUM(Sales) AS TotalSales, SUM(Profit) AS TotalProfit FROM orders;
-- Output --
"totalsales"	"totalprofit"
2297200.8603	286397.0217

-- Top 5 Sub-Categories by Sales --
SELECT SubCategory, SUM(Sales) AS Sales
FROM orders
GROUP BY SubCategory
ORDER BY Sales DESC
LIMIT 5;
-- Output --
"subcategory"	"sales"
"Phones"	330007.054
"Chairs"	328449.103
"Storage"	223843.608
"Tables"	206965.5320
"Binders"	203412.733

-- Profitable Region --
SELECT Region, SUM(Profit) AS TotalProfit
FROM orders
GROUP BY Region
ORDER BY TotalProfit DESC;
-- Output --
"region"	"totalprofit"
"West"	108418.4489
"East"	91522.7800
"South"	46749.4303
"Central"	39706.3625

-- Sales & Profit by Ship Mode --
SELECT ShipMode, SUM(Sales) AS Sales, SUM(Profit) AS Profit
FROM orders
GROUP BY ShipMode;
-- Output --
"shipmode"	"sales"	"profit"
"Standard Class"	1358215.7430	164088.7875
"Second Class"	459193.5694	57446.6354
"Same Day"	128363.125	15891.7589
"First Class"	351428.4229	48969.8399

-- Sales by Customer Segment --
SELECT Segment, SUM(Sales) AS Sales, SUM(Profit) AS Profit
FROM orders
GROUP BY Segment;
-- Output --
"segment"	"sales"	"profit"
"Consumer"	1161401.3450	134119.2092
"Corporate"	706146.3668	91979.1340
"Home Office"	429653.1485	60298.6785

-- Top 5 States by Sales --
SELECT State, SUM(Sales) AS Sales
FROM orders
GROUP BY State
ORDER BY Sales DESC
LIMIT 5;
-- Output --
"state"	"sales"
"California"	457687.6315
"New York"	310876.271
"Texas"	170188.0458
"Washington"	138641.270
"Pennsylvania"	116511.914

-- States with Negative Total Profit (Loss-Making States) --
SELECT State, SUM(Profit) AS TotalProfit
FROM orders
GROUP BY State
HAVING SUM(Profit) < 0
ORDER BY TotalProfit ASC;
-- Output --
"state"	"totalprofit"
"Texas"	-25729.3563
"Ohio"	-16971.3766
"Pennsylvania"	-15559.9603
"Illinois"	-12607.8870
"North Carolina"	-7490.9122
"Colorado"	-6527.8579
"Tennessee"	-5341.6936
"Arizona"	-3427.9246
"Florida"	-3399.3017
"Oregon"	-1190.4705

--  City-wise Sales in a Specific Region('West') --
SELECT City, SUM(Sales) AS Sales
FROM orders
WHERE Region = 'West'
GROUP BY City
ORDER BY Sales DESC
limit 5;
-- Output --
"city"	"sales"
"Los Angeles"	175851.3410
"Seattle"	119540.742
"San Francisco"	112669.092
"San Diego"	47521.029
"Denver"	12198.793


-- Average Discount by Category --
SELECT Category, AVG(Discount) AS AvgDiscount
FROM orders
GROUP BY Category;
-- Output -- 
"category"	"avgdiscount"
"Furniture"	0.17392267798208392268
"Office Supplies"	0.15728509790906073681
"Technology"	0.13232268543584190579

--  Total Quantity Sold by Sub-Category --
SELECT SubCategory, SUM(Quantity) AS TotalQuantity
FROM orders
GROUP BY SubCategory
ORDER BY TotalQuantity DESC;
-- Output -- 
"subcategory"	"totalquantity"
"Binders"	5974
"Paper"	5178
"Furnishings"	3563
"Phones"	3289
"Storage"	3158

-- Profit Margin (Profit/Sales) by Category --
SELECT Category,
       SUM(Profit) AS TotalProfit,
       SUM(Sales) AS TotalSales,
       (SUM(Profit) / SUM(Sales)) * 100 AS ProfitMarginPercent
FROM orders
GROUP BY Category;
-- Output --
"category"	"totalprofit"	"totalsales"	"profitmarginpercent"
"Furniture"	18451.2728	741999.7953	2.48669513345888654900
"Office Supplies"	122490.8008	719047.032	17.03515839002865114400
"Technology"	145454.9481	836154.033	17.39571207689193792400
